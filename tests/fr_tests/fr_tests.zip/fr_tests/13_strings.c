int first_char_is_A(const char *s) {
    return s[0] == 'A';
}
