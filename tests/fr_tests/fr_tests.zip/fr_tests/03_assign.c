int assign(int x) {
    int y = x + 1;
    y += 3;
    y *= 2;
    return y;
}
