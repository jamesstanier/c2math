int incp(int *px) {
    (*px)++;
    return *px;
}
