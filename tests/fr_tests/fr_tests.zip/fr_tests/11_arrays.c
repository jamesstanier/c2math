int sum3(const int a[3]) {
    return a[0] + a[1] + a[2];
}
