int forty_two(void) {
    return 42;
}
