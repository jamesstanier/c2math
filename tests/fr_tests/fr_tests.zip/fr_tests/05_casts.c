int casts(double d) {
    int i = (int)d;
    return i;
}
