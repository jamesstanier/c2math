int sel(int a, int b, int c) {
    int m = (a < b) ? a : b;
    return m + c;
}
