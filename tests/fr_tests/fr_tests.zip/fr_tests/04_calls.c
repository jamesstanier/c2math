static int inc(int x) { return x + 1; }

int use_inc(int z) {
    return inc(z);
}
